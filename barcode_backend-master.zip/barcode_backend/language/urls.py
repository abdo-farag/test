from rest_framework import routers
from django.conf.urls import url, include
from .views import *

app_name = 'language'
router = routers.DefaultRouter()
router.register(r'languages', LanguageViewSet)
router.register(r'length', LengthUnitViewSet)
router.register(r'weight', WeightUnitViewSet)

urlpatterns = [
    url(r'^[a-zA-Z-]+/', include(router.urls)),
]