from rest_framework import serializers
from .models import *


class LanguageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Language
        fields = '__all__'

class WeightUnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = WeightUnit
        fields = '__all__'

class LengthUnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = LengthUnit
        fields = '__all__'
