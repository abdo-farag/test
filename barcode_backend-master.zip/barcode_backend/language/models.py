from django.db import models

# Create your models here.
class WeightUnit(models.Model):
    name = models.CharField(max_length=30)
    conversion_rate = models.FloatField()
    def convert_to(self, value):
        return self.conversion_rate * float(value)
    def convert_from(self, value):
        return self.conversion_rate / float(value)

class LengthUnit(models.Model):
    name = models.CharField(max_length=30)
    conversion_rate = models.FloatField()
    def convert_to(self, value):
        return self.conversion_rate * float(value)
    def convert_from(self, value):
        return self.conversion_rate / float(value)

class Language(models.Model):
    name =  models.CharField(max_length=30)
    weight_unit =  models.ForeignKey(WeightUnit, on_delete=models.CASCADE)
    length_unit = models.ForeignKey(LengthUnit, on_delete=models.CASCADE)
    def __str__(self):
        return self.name