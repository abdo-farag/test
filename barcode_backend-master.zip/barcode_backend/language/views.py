from rest_framework import viewsets
from .models import Language, WeightUnit, LengthUnit
from .serializers import LanguageSerializer, WeightUnitSerializer, LengthUnitSerializer
from scanapp.utils import get_language
# Create your views here.

class LanguageViewSet(viewsets.ModelViewSet):
    queryset = Language.objects.all()
    serializer_class = LanguageSerializer
    model_class = Language
    

class WeightUnitViewSet(viewsets.ModelViewSet):
    queryset = WeightUnit.objects.all()
    serializer_class = WeightUnitSerializer
    model_class = WeightUnit

class LengthUnitViewSet(viewsets.ModelViewSet):
    queryset = LengthUnit.objects.all()
    serializer_class = LengthUnitSerializer
    model_class = LengthUnit

