from rest_framework import routers
from django.conf.urls import url, include
from .views import FrontendTextViewSet

app_name = 'frontend'
router = routers.DefaultRouter()
router.register(r'', FrontendTextViewSet)

urlpatterns = [
    url(r'^[a-zA-Z-]+/', include(router.urls)),
]