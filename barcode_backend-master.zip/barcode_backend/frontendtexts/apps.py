from django.apps import AppConfig


class FrontendtextsConfig(AppConfig):
    name = 'frontendtexts'
