from django.shortcuts import render
from rest_framework import viewsets
from .serializers import FrontendTextSerializer
from .models import FrontendText
from scanapp.utils import get_language
# Create your views here.

class FrontendTextViewSet(viewsets.ModelViewSet):
    queryset = FrontendText.objects.all()
    serializer_class = FrontendTextSerializer
    model_class = FrontendText

    def get_queryset(self):
        language = get_language(self.request)
        return self.model_class.getAll(language)