from rest_framework import serializers
from .models import *

class FrontendTextSerializer(serializers.ModelSerializer):
    id = serializers.ReadOnlyField()
    class Meta:
        model = FrontendText
        fields = '__all__'
