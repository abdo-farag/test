## BARCODE SCANNER BACKEND
It contains the following 
* MyAuth
* Scanapp
* Language
* Frontends

### Installation
`Run pip -r requirements.txt`
`Run python manage.py makemigrations`
`Run python manage.py migrate`

Then create a superuser account using
`python manage.py createsuperuser`

Then start the app using
`python manage.py runserver`

### Language App
It contains list of supported languages, weight unit and length unit
At least a record of language model must be created before the app can be used.

To create a new record go to
`host/api/admin/language`

#### FrontendText App
It contains all the list of texts at the frontend.
Atlease a record of it is needed before the frontend can work

To create a new record go to
`host/api/admin/FrontendText`

### Scanapp App
It contains the following endpoints all of which require authorization.

* product_types
* ean_codes
* products
* product_pictures
* product_hier
* bom

All endpoints are located at host/api/scanapp/{LANG}/{endpoint}/ where 
* {LANG} is the name of the requested language
* {endpoint} is the endpoint as written above