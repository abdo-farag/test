from django.shortcuts import render
from rest_framework import viewsets
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from .models import OAuth
from .serializers import OAuthSerializer
# Create your views here.

from allauth.socialaccount.providers.google.views import GoogleOAuth2Adapter
from rest_auth.registration.views import SocialLoginView
@method_decorator(csrf_exempt, name='dispatch')
class GoogleLogin(SocialLoginView):
    adapter_class = GoogleOAuth2Adapter

class OAuthViewSet(viewsets.ModelViewSet):
    queryset = OAuth.objects.all()
    serializer_class = OAuthSerializer
    model_class = OAuth
    