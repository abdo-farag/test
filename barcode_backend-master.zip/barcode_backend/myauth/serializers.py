from rest_framework import serializers
from .models import OAuth


class OAuthSerializer(serializers.ModelSerializer):
    scopes = serializers.SerializerMethodField()
    loginPath = serializers.SerializerMethodField()
    auth_data = serializers.SerializerMethodField()
    class Meta:
        model = OAuth
        fields = '__all__'
    def get_scopes(self, obj):
        return obj.scopes.split(',')
    def get_auth_data(self, obj):
        a = {
            'clientId': obj.clientId,
            'clientSecret': obj.clientSecret,
            'accessTokenUri': obj.accessTokenUri,
            'state': obj.state,
            'authorizationUri': obj.authorizationUri,
            'redirectUri': obj.redirectUri,
            'scopes': self.get_scopes(obj),
            'responseType': obj.responseType
        }
        return a
    def get_loginPath(self, obj):
        return reverse(obj.loginPath)

