from django.contrib import admin
from .models import *
from allauth.models import *
# Register your models here.
admin.site.register(OAuth)