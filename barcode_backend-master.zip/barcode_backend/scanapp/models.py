from django.db import models
from django.contrib.auth.models import User as NormalUser
import secrets
# Create your models here.
# from model import *


class User(models.Model):
    user_id = models.CharField(max_length=30, unique=True)
    _social = models.CharField(max_length=30, default="none")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def getUser(user_model):
        user = None
        if isinstance(user_model, NormalUser):
            try:
                object = User.objects.get(user_id = 'normal_'+ user_model.username)
                return object
            except Exception as e:
                user = User()
                user.user_id = 'normal_' + user_model.username
                user.social = 'normal'
                user.save()
                return user
        return user
    def __str__(self):
        return self.user_id

class UserActivity(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    activity = models.CharField(max_length=30)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "{0}:{1}".format(self.user, self.created_at)
    
class ProductType(models.Model):
    is_packaging_material = models.BooleanField(default=False)
    icon = models.CharField(max_length=30)
    deleted = models.BooleanField(default=False)
    name = models.CharField(max_length=30)
    def getAll(language):
        objects = ProductType.objects.all()
        [object.get_with_locale(language) for object in objects]
        return objects

    def get_with_locale(self, language):
        try:
            self.title = ProductTypeTranslation.objects.get(word_id=self.id, language=language.id ).translation
        except:
            self.title = ProductTypeTranslation.objects.get(word_id=self.id, language=1 ).translation
        return self

    def __str__(self):
        return self.name
class ProductTypeTranslation(models.Model):
    word_id = models.ForeignKey(ProductType, on_delete=models.CASCADE)
    language = models.ForeignKey('language.Language', on_delete=models.CASCADE)
    translation = models.CharField(max_length=40)

    def __str__(self):
        return str(self.word_id) + '-' + str(self.language)

class EAN_Code(models.Model):
    #product_type = models.ForeignKey(ProductType, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    deleted = models.BooleanField(default=False)
    barcode = models.CharField(max_length=50)

class Product(models.Model):
    name = models.CharField(max_length=30)
    packaging_material = models.ForeignKey(ProductType, related_name='materials', on_delete=models.CASCADE)
    EAN_code = models.ForeignKey(EAN_Code, related_name='products', on_delete=models.CASCADE)
    weight = models.CharField(max_length=20)
    length = models.FloatField()
    width = models.FloatField()
    height = models.FloatField()
    is_generic = models.BooleanField()
    deleted = models.BooleanField(default=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    product_type = models.ForeignKey('scanapp.ProductType', on_delete=models.CASCADE)

    def __str__(self):
        return self.name

class ProductPicture(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='pictures')
    name = models.CharField(max_length=30)
    image = models.FileField(upload_to='image/')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def get_url(self):
        return '/' + self.image.url
    
    def __str__(self):
        return str(self.product) + "_picture"

class ProductTypeHier(models.Model):
    parent = models.ForeignKey(ProductType, on_delete=models.CASCADE, related_name='parent')
    child = models.ForeignKey(ProductType, on_delete=models.CASCADE)
    def __str__(self):
        return str(self.parent) + '  -  ' + str(self.child)

class BOM(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    product_type = models.ForeignKey(ProductType, on_delete=models.CASCADE)
    weight = models.CharField(max_length=30)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True) 

    def __str__(self):
        return str(self.product) + '-bom'
