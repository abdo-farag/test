from scanapp.models import *
from scanapp.utils import get_language
from rest_framework import serializers
from django.urls import reverse



class UserSerializer(serializers.ModelSerializer):
    _token = serializers.ReadOnlyField()
    password = serializers.CharField(write_only=True)
    class Meta:
        model = User
        fields = ('user_id', '_token', 'password')

class UserActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = UserActivity
        fields = ('id', 'user_id', 'activity')

class ProductTypeSerializer(serializers.ModelSerializer):
    title = serializers.ReadOnlyField()
    class Meta:
        model = ProductType
        fields = ('id','is_packaging_material', 'title', 'name', 'deleted', 'product_set')
    def get_url(self, obj):
        request = self.context['request']
        return reverse('download-image', kwargs={'image_id': obj.id, image_folder: 'product_type_icon'}, request=request)
class ProductPictureSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()
    image = serializers.FileField(write_only=True)
    class Meta:
        model = ProductPicture
        fields = ('id', 'url', 'name', 'image', 'product')
    
    def get_url(self, obj):
        request = self.context['request']
        return reverse('download_product_picture', kwargs={'pk': obj.id}) 
class ProductPictureLinkField(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()

    class Meta:
        model = ProductPicture
        fields = ('url',)
    
    def to_representation(self, value):
        return self.get_url(value)
    
    def get_url(self, obj):
        request = self.context['request']
        return reverse('download_product_picture', kwargs={'pk': obj.id}) 

class ProductWriteSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Product
        fields = '__all__'
        write_only_fields = ('weight',)
        read_only_fields = ('user',)

    def to_internal_value(self, data):
        
        return super(ProductWriteSerializer, self).to_internal_value(data)

class ProductSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(read_only=True)
    weight = serializers.SerializerMethodField()
    length = serializers.SerializerMethodField()
    width = serializers.SerializerMethodField()
    height = serializers.SerializerMethodField()
    icon_link = serializers.SerializerMethodField()
    pictures = ProductPictureLinkField(many=True, read_only=True)
    class Meta:
        model = Product
        fields = '__all__'
        write_only_fields = ('weight',)
        read_only_fields = ('icon_link',)
    def get_weight(self, obj):
        language = get_language(self.context['request'])
        return str(language.weight_unit.convert_to(obj.weight)) + language.weight_unit.name
    def get_length(self, obj):
        language = get_language(self.context['request'])
        return str(language.length_unit.convert_to(obj.length)) + language.length_unit.name
    def get_width(self, obj):
        language = get_language(self.context['request'])
        return str(language.length_unit.convert_to(obj.width)) + language.length_unit.name
    def get_height(self, obj):
        language = get_language(self.context['request'])
        return str(language.length_unit.convert_to(obj.height)) + language.length_unit.name
    def get_icon_link(self, obj):
        icon = None
        try:
            icon = obj.pictures.all()[0]
        except:
            icon = ProductPicture.objects.get(pk=1)
        return reverse('download_product_picture', kwargs={'pk': icon.id})

class EAN_CodeSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(read_only=True)
    products = ProductSerializer(many=True, read_only=True)
    class Meta:
        model = EAN_Code
        fields = ('id', 'user', 'barcode', 'deleted', 'products')


class ProductTypeHierSerializer(serializers.ModelSerializer):

    class Meta:
        model = ProductTypeHier
        fields = '__all__'

class BOMSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(read_only=True)
    class Meta:
        model = BOM
        fields = ('product', 'product_type', 'weight')

class ProductTypeHierMainSerializer(serializers.ModelSerializer):
    children = serializers.SerializerMethodField(read_only=True)
    name = serializers.SerializerMethodField(read_only=True)
    label = serializers.SerializerMethodField()
    title = serializers.ReadOnlyField()
    
    class Meta:
        model = ProductType
        fields = ('children','name', 'title', 'label', 'id')

    def get_label(self, obj):
        language = get_language(self.context['request'])
        return obj.get_with_locale(language).title
        

    def get_name(self, obj):
        return obj.name
    def get_children(self, obj):
        product_type_hiers = ProductTypeHier.objects.filter(parent=obj)
        product_children = []
        [product_children.append(temp.child) for temp in product_type_hiers]
        product_types = ProductTypeHierMainSerializer(product_children, many=True, context=self.context)
        return product_types.data
