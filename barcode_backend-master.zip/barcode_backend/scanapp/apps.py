from django.apps import AppConfig


class ScanappConfig(AppConfig):
    name = 'scanapp'
