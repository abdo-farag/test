from language.models import Language, WeightUnit, LengthUnit

def get_language(request):
    '''
     return language by path or return default language
     if the language specified in 
     the request does not exist
    '''
    path = request.path
    lang = path.split('/')[2]
    try:
        return Language.objects.get(name=lang.upper())
    except:
        return Language.objects.get(pk=1)
    

def get_weight_unit(data):
    try:
        return WeightUnit.objects.get(name=data)
    except:
        return WeightUnit.objects.get(pk=1)
def get_length_unit(data):
    try:
        return LengthUnit.objects.get(name=data)
    except:
        return LengthUnit.objects.get(pk=1)