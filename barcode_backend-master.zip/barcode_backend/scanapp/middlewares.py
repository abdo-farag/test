from scanapp.models import User, UserActivity

class ActivityMiddleware:
    # This middleware run on all scanapp endpoint and record acivities on UserActivity Table
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        print(request.path)
        if request.path.split('/')[0] == 'admin':
            return response
        if not 'scanapp' in request.path:
            return response 
        try:
            activity = UserActivity()
            user = User.getUser(request.user)
            activity.user = user 
            activity.activity = request.path
            activity.save()
            return response
        except Exception as e:
            return response
