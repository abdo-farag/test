from django.contrib import admin
from scanapp.models import *
# Register your models here.
admin.site.register(User)
admin.site.register(Product)
admin.site.register(ProductType)
admin.site.register(ProductTypeTranslation)
admin.site.register(ProductTypeHier)
admin.site.register(EAN_Code)
admin.site.register(BOM)
admin.site.register(ProductPicture)
admin.site.register(UserActivity)



