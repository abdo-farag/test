from django.conf.urls import url, include
from rest_framework import routers
from scanapp.views import *
from django.urls import path

app_name = 'scanapp'
router = routers.DefaultRouter()
router.register(r'product_types', ProductTypeViewSet)
router.register(r'ean_codes', EAN_CodeViewSet)
router.register(r'products', ProductViewSet)
router.register(r'product_pictures', ProductPictureViewSet)
router.register(r'product_hier', ProductTypeHierMainViewSet)
router.register(r'bom', BOMViewSet)
urlpatterns = [
    url(r'^[a-zA-Z-]+/', include(router.urls)),
    path(r'<slug:language>/product_type_children/<int:pk>/', get_product_types),
    path(r'<slug:language>/units/', get_units),
]
