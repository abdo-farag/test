import json
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from django.http import HttpResponse
from django.utils.decorators import method_decorator
from scanapp.serializers import *
from rest_framework import viewsets, status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
# Create your views here.

@api_view(['GET'])
def get_units(request, language):
    units = {
        'weight': [
            {'label': 'kg', 'value': 'kg'},
            {'label': 'lb', 'value': 'lb'}
        ],
        'length': [
            {'label': 'm', 'value': 'm'},
            {'label': 'in', 'value': 'in'}        ]
    }
    return Response(units)

@api_view(['GET'])
def get_product_types(request, pk, language):
    product_type = ProductType.objects.get(pk=pk)
    #print(product_type)
    product_type_hiers = ProductTypeHier.objects.filter(parent=product_type)
    product_children = []
    [product_children.append(temp.child) for temp in product_type_hiers]
    product_types = ProductTypeSerializer(product_children, many=True)
    response = Response(product_types.data)
    return response

def download_product_picture(request, pk):
    image = ProductPicture.objects.get(pk=pk)
    response = HttpResponse()
    #print(image)
    print(image.get_url())
    response['X-Accel-Redirect'] =  image.get_url()
    response['Content-Disposition'] = 'attachment; filename="{}"'.format(image.name)
    return response

class MyViewSet(viewsets.ModelViewSet):
    model_class = None
    permission_classes = (IsAuthenticated,)
    def list(self, request):
        return super(viewsets.ModelViewSet, self).list(request)
class TranslationViewSet(object):
    """docstring for TranslationViewSet"""
        
    def get_queryset(self):
        language = get_language(self.request)
        return self.model_class.getAll(language)

    def get_object(self):
        object = super(viewsets.ModelViewSet, self).get_object()
        language = get_language(self.request)
        return object.get_with_locale(language)

class AutoSetUser(object):
    def perform_create(self, serializer):
        serializer.save(user=User.getUser(self.request.user))

def create_viewset(base, name, queryset, serializer_class, model_class):
    return type(name, (base,), {'queryset': queryset,
                'serializer_class': serializer_class, 'model_class':model_class})

class ProductTypeViewSet(AutoSetUser, TranslationViewSet, MyViewSet):
    queryset = ProductType.objects.all()
    serializer_class = ProductTypeSerializer
    model_class = ProductType

class EAN_CodeViewSet(AutoSetUser, MyViewSet):
    queryset = EAN_Code.objects.all()
    serializer_class = EAN_CodeSerializer
    model_class = EAN_Code
    lookup_field = 'barcode'


class ProductViewSet(AutoSetUser, MyViewSet):
    queryset = Product.objects.all()
    write_serializer_class = ProductWriteSerializer
    read_serializer_class = ProductSerializer
    model_class = Product

    def get_serializer(self, *args, **kwargs):
        if(self.request.method == 'PUT' or self.request.method == 'PATCH' or self.request.method == 'POST'):
            self.serializer_class = self.write_serializer_class
        else:
            self.serializer_class = self.read_serializer_class
        return super(MyViewSet, self).get_serializer(*args, **kwargs)

class ProductPictureViewSet(AutoSetUser, MyViewSet):
    queryset = ProductPicture.objects.all()
    serializer_class = ProductPictureSerializer
    model_class = ProductPicture

class ProductTypeHierViewSet(AutoSetUser, MyViewSet):
    queryset = ProductTypeHier.objects.all()
    serializer_class = ProductTypeHierSerializer
    model_class = ProductTypeHier

class ProductTypeHierMainViewSet(AutoSetUser, MyViewSet):
    queryset = ProductType.objects.all()
    serializer_class = ProductTypeHierMainSerializer
    model_class = ProductType

class BOMViewSet(AutoSetUser, MyViewSet):
    queryset = BOM.objects.all()
    serializer_class = BOMSerializer
    model_class = BOM

